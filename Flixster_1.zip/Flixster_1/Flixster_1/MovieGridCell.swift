//
//  MovieGridCell.swift
//  Flixster_1
//
//  Created by Ja Brian Stanley on 2/7/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
